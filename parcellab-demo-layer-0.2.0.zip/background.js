// src/shared/auth.ts
var OAUTH_ISSUER_URL = "https://auth.parcellab.com/realms/parcellab";
var OAUTH_CLIENT_ID = "chrome-demo-layer";
var OAUTH_SCOPES = "openid profile email roles";
var AUTH_STORAGE_KEY = "oauthTokens";
function generateRandomBytes(length) {
  return crypto.getRandomValues(new Uint8Array(length));
}
function base64UrlEncode(bytes) {
  const binary = Array.from(bytes).map((b) => String.fromCharCode(b)).join("");
  return btoa(binary).replace(/\+/g, "-").replace(/\//g, "_").replace(/=+$/, "");
}
async function sha256(input) {
  const encoder = new TextEncoder();
  return crypto.subtle.digest("SHA-256", encoder.encode(input));
}
function generateCodeVerifier() {
  return base64UrlEncode(generateRandomBytes(64));
}
async function generateCodeChallenge(verifier) {
  const hash = await sha256(verifier);
  return base64UrlEncode(new Uint8Array(hash));
}
var cachedOIDCConfig = null;
async function getOIDCConfig() {
  if (cachedOIDCConfig) return cachedOIDCConfig;
  const response = await fetch(
    `${OAUTH_ISSUER_URL}/.well-known/openid-configuration`
  );
  if (!response.ok) {
    throw new Error(`OIDC discovery failed (${response.status})`);
  }
  cachedOIDCConfig = await response.json();
  return cachedOIDCConfig;
}
async function getStoredTokens() {
  const result = await chrome.storage.local.get(
    AUTH_STORAGE_KEY
  );
  return result[AUTH_STORAGE_KEY] ?? null;
}
async function storeTokens(tokens) {
  await chrome.storage.local.set({ [AUTH_STORAGE_KEY]: tokens });
}
async function clearTokens() {
  await chrome.storage.local.remove(AUTH_STORAGE_KEY);
}
var REFRESH_BUFFER_MS = 6e4;
async function refreshAccessToken(refreshToken) {
  const oidc = await getOIDCConfig();
  const body = new URLSearchParams({
    grant_type: "refresh_token",
    client_id: OAUTH_CLIENT_ID,
    refresh_token: refreshToken
  });
  const response = await fetch(oidc.token_endpoint, {
    method: "POST",
    headers: { "Content-Type": "application/x-www-form-urlencoded" },
    body: body.toString()
  });
  if (!response.ok) {
    await clearTokens();
    throw new Error("Session expired. Please log in again.");
  }
  const data = await response.json();
  const tokens = {
    accessToken: data.access_token,
    refreshToken: data.refresh_token ?? refreshToken,
    idToken: data.id_token ?? "",
    expiresAt: Date.now() + data.expires_in * 1e3
  };
  await storeTokens(tokens);
  return tokens;
}
async function getValidAccessToken() {
  const tokens = await getStoredTokens();
  if (!tokens) return null;
  if (Date.now() < tokens.expiresAt - REFRESH_BUFFER_MS) {
    return tokens.accessToken;
  }
  if (!tokens.refreshToken) {
    await clearTokens();
    return null;
  }
  try {
    const refreshed = await refreshAccessToken(tokens.refreshToken);
    return refreshed.accessToken;
  } catch {
    return null;
  }
}
async function login() {
  const oidc = await getOIDCConfig();
  const redirectUrl = chrome.identity.getRedirectURL("oauth/callback");
  const codeVerifier = generateCodeVerifier();
  const codeChallenge = await generateCodeChallenge(codeVerifier);
  const state = base64UrlEncode(generateRandomBytes(16));
  const authParams = new URLSearchParams({
    client_id: OAUTH_CLIENT_ID,
    redirect_uri: redirectUrl,
    response_type: "code",
    scope: OAUTH_SCOPES,
    state,
    code_challenge: codeChallenge,
    code_challenge_method: "S256"
  });
  const authUrl = `${oidc.authorization_endpoint}?${authParams.toString()}`;
  const callbackUrl = await new Promise((resolve, reject) => {
    chrome.identity.launchWebAuthFlow(
      { url: authUrl, interactive: true },
      (responseUrl) => {
        if (chrome.runtime.lastError || !responseUrl) {
          reject(
            new Error(
              chrome.runtime.lastError?.message ?? "Authentication cancelled."
            )
          );
          return;
        }
        resolve(responseUrl);
      }
    );
  });
  const callbackParams = new URL(callbackUrl).searchParams;
  const code = callbackParams.get("code");
  const returnedState = callbackParams.get("state");
  if (!code) {
    const error = callbackParams.get("error_description") ?? callbackParams.get("error") ?? "No authorization code received.";
    throw new Error(error);
  }
  if (returnedState !== state) {
    throw new Error("OAuth state mismatch. Please try again.");
  }
  const tokenBody = new URLSearchParams({
    grant_type: "authorization_code",
    client_id: OAUTH_CLIENT_ID,
    redirect_uri: redirectUrl,
    code,
    code_verifier: codeVerifier
  });
  const tokenResponse = await fetch(oidc.token_endpoint, {
    method: "POST",
    headers: { "Content-Type": "application/x-www-form-urlencoded" },
    body: tokenBody.toString()
  });
  if (!tokenResponse.ok) {
    const text = await tokenResponse.text().catch(() => "");
    throw new Error(`Token exchange failed (${tokenResponse.status}): ${text || tokenResponse.statusText}`);
  }
  const tokenData = await tokenResponse.json();
  const tokens = {
    accessToken: tokenData.access_token,
    refreshToken: tokenData.refresh_token ?? "",
    idToken: tokenData.id_token ?? "",
    expiresAt: Date.now() + tokenData.expires_in * 1e3
  };
  await storeTokens(tokens);
  return tokens;
}
async function logout() {
  await clearTokens();
}
function isAuthenticated(tokens) {
  return tokens !== null && tokens.expiresAt > Date.now();
}

// src/shared/demo.ts
function normalizeDemoConfig(value) {
  if (!value) {
    return void 0;
  }
  if ("kind" in value && value.kind === "returns-portal") {
    return {
      kind: "returns-portal",
      accountName: value.accountName,
      portalCode: value.portalCode,
      lang: value.lang
    };
  }
  if ("kind" in value && value.kind === "selection-guide") {
    const sg = value;
    return {
      kind: "selection-guide",
      accountId: sg.accountId,
      productId: sg.productId,
      locale: sg.locale,
      appearance: sg.appearance ?? "neutral",
      density: sg.density ?? "compact",
      surface: sg.surface ?? "subtle",
      notFoundMode: sg.notFoundMode ?? "true-to-size"
    };
  }
  if ("kind" in value && value.kind === "chatbot") {
    const cb = value;
    return {
      kind: "chatbot",
      agentId: cb.agentId,
      baseUrl: cb.baseUrl
    };
  }
  if ("kind" in value && value.kind === "track-and-trace") {
    return {
      kind: "track-and-trace",
      userId: value.userId,
      lang: value.lang,
      showArticleList: value.showArticleList
    };
  }
  if ("userId" in value) {
    return {
      kind: "track-and-trace",
      userId: value.userId,
      lang: value.lang,
      showArticleList: value.showArticleList
    };
  }
  return void 0;
}

// src/shared/url.ts
function normalizeScopeUrl(value) {
  const url = new URL(value);
  url.search = "";
  url.hash = "";
  return url.toString();
}
function toMatchPattern(value) {
  const url = new URL(value);
  const protocol = url.protocol.replace(":", "");
  const path = url.pathname === "/" ? "/*" : `${url.pathname}*`;
  return `${protocol}://${url.host}${path}`;
}

// src/shared/storage.ts
var MODIFICATIONS_KEY = "savedModifications";
async function getSavedModifications() {
  const result = await chrome.storage.local.get(
    MODIFICATIONS_KEY
  );
  return Array.isArray(result.savedModifications) ? result.savedModifications.map(normalizeSavedModification).sort(sortNewestFirst) : [];
}
function resolveRuleScopeUrl(rule) {
  return rule.scopeUrl ?? normalizeScopeUrl(rule.url);
}
function sortNewestFirst(a, b) {
  return b.createdAt.localeCompare(a.createdAt);
}
function normalizeSavedModification(rule) {
  const demoConfig = normalizeDemoConfig(rule.demoConfig);
  if (!demoConfig || demoConfig === rule.demoConfig) {
    return rule;
  }
  return {
    ...rule,
    demoConfig
  };
}

// src/background/index.ts
var CONTENT_SCRIPT_ID = "parcellab-demo-content-script";
chrome.runtime.onInstalled.addListener(() => {
  void syncRegisteredContentScript();
});
chrome.runtime.onStartup.addListener(() => {
  void syncRegisteredContentScript();
});
chrome.runtime.onMessage.addListener(
  (message, sender, sendResponse) => {
    if (message?.type === "SYNC_RULES") {
      void syncRegisteredContentScript().then(() => sendResponse({ ok: true })).catch(
        (error) => sendResponse({
          ok: false,
          error: error instanceof Error ? error.message : String(error)
        })
      );
      return true;
    }
    if (message?.type === "RENDER_TRACK_AND_TRACE" && sender.tab?.id) {
      void renderTrackAndTrace(
        sender.tab.id,
        message.containerId,
        message.demoConfig
      ).then(() => sendResponse({ ok: true })).catch(
        (error) => sendResponse({
          ok: false,
          error: error instanceof Error ? error.message : String(error)
        })
      );
      return true;
    }
    if (message?.type === "RENDER_SELECTION_GUIDE" && sender.tab?.id) {
      void renderSelectionGuide(
        sender.tab.id,
        message.containerId,
        message.demoConfig
      ).then(() => sendResponse({ ok: true })).catch(
        (error) => sendResponse({
          ok: false,
          error: error instanceof Error ? error.message : String(error)
        })
      );
      return true;
    }
    if (message?.type === "RENDER_RETURNS_PORTAL" && sender.tab?.id) {
      void renderReturnsPortal(
        sender.tab.id,
        message.containerId,
        message.demoConfig
      ).then(() => sendResponse({ ok: true })).catch(
        (error) => sendResponse({
          ok: false,
          error: error instanceof Error ? error.message : String(error)
        })
      );
      return true;
    }
    if (message?.type === "CHATBOT_EXECUTE") {
      void handleChatbotExecute(message).then((response) => sendResponse(response)).catch(
        (error) => sendResponse({
          ok: false,
          error: error instanceof Error ? error.message : String(error)
        })
      );
      return true;
    }
    if (message?.type === "AUTH_LOGIN") {
      void login().then(() => sendResponse({ ok: true })).catch(
        (error) => sendResponse({
          ok: false,
          error: error instanceof Error ? error.message : String(error)
        })
      );
      return true;
    }
    if (message?.type === "AUTH_LOGOUT") {
      void logout().then(() => sendResponse({ ok: true })).catch(
        (error) => sendResponse({
          ok: false,
          error: error instanceof Error ? error.message : String(error)
        })
      );
      return true;
    }
    if (message?.type === "AUTH_STATUS") {
      void getStoredTokens().then(
        (tokens) => sendResponse({
          ok: true,
          authenticated: isAuthenticated(tokens)
        })
      ).catch(
        () => sendResponse({ ok: true, authenticated: false })
      );
      return true;
    }
    return void 0;
  }
);
async function syncRegisteredContentScript() {
  const rules = await getSavedModifications();
  const matches = Array.from(
    new Set(rules.map((rule) => toMatchPattern(resolveRuleScopeUrl(rule))))
  );
  const existing = await chrome.scripting.getRegisteredContentScripts({
    ids: [CONTENT_SCRIPT_ID]
  });
  if (existing.length > 0) {
    await chrome.scripting.unregisterContentScripts({ ids: [CONTENT_SCRIPT_ID] });
  }
  if (matches.length === 0) {
    return;
  }
  await chrome.scripting.registerContentScripts([
    {
      id: CONTENT_SCRIPT_ID,
      js: ["content.js"],
      matches,
      persistAcrossSessions: true,
      runAt: "document_idle"
    }
  ]);
}
async function renderTrackAndTrace(tabId, containerId, demoConfig) {
  const [{ result }] = await chrome.scripting.executeScript({
    target: { tabId },
    world: "MAIN",
    args: [containerId, demoConfig],
    func: (targetContainerId, config) => {
      const SCRIPT_ID = "pl-demo-track-and-trace-script";
      const STYLES_ID = "pl-demo-track-and-trace-styles";
      const SCRIPT_SRC = "https://cdn.parcellab.com/js/v5/main.min.js";
      const STYLES_SRC = "https://cdn.parcellab.com/css/v5/main.min.css";
      const scopedWindow = window;
      const container = document.getElementById(targetContainerId);
      if (!container) {
        return { ok: false, error: "Track and trace container not found." };
      }
      const showContainerError = (message) => {
        container.dataset.plDemoTrackRequested = "false";
        container.dataset.plDemoTrackRendered = "false";
        const wrapper = document.createElement("div");
        wrapper.style.margin = "24px auto";
        wrapper.style.maxWidth = "560px";
        wrapper.style.padding = "16px 18px";
        wrapper.style.border = "1px solid rgba(239, 68, 68, 0.25)";
        wrapper.style.borderRadius = "12px";
        wrapper.style.background = "#fef2f2";
        wrapper.style.color = "#991b1b";
        wrapper.style.font = "500 14px/1.5 system-ui, sans-serif";
        wrapper.textContent = message;
        container.replaceChildren(wrapper);
      };
      const renderKey = `${config.userId}:${config.lang}:${String(
        config.showArticleList
      )}`;
      if (container.dataset.plDemoTrackKey === renderKey && container.dataset.plDemoTrackRendered === "true") {
        return { ok: true };
      }
      container.dataset.plDemoTrackKey = renderKey;
      container.dataset.plDemoTrackRequested = "running";
      container.dataset.plDemoTrackRendered = "false";
      if (!document.getElementById(STYLES_ID)) {
        const linkTag = document.createElement("link");
        linkTag.id = STYLES_ID;
        linkTag.rel = "stylesheet";
        linkTag.href = STYLES_SRC;
        document.head.appendChild(linkTag);
      }
      const ensureScript = async () => {
        if (typeof scopedWindow.parcelLabTrackAndTrace?.initialize === "function") {
          return;
        }
        if (scopedWindow.__plDemoTrackLoaderPromise__) {
          return scopedWindow.__plDemoTrackLoaderPromise__;
        }
        scopedWindow.__plDemoTrackLoaderPromise__ = new Promise(
          (resolve, reject) => {
            const existingScript = document.getElementById(
              SCRIPT_ID
            );
            if (existingScript) {
              if (existingScript.dataset.plDemoLoaded === "true") {
                resolve();
                return;
              }
              existingScript.addEventListener("load", () => resolve(), {
                once: true
              });
              existingScript.addEventListener(
                "error",
                () => reject(new Error("Could not load parcelLab script.")),
                { once: true }
              );
              return;
            }
            const scriptTag = document.createElement("script");
            scriptTag.id = SCRIPT_ID;
            scriptTag.async = true;
            scriptTag.src = SCRIPT_SRC;
            scriptTag.onload = () => {
              scriptTag.dataset.plDemoLoaded = "true";
              resolve();
            };
            scriptTag.onerror = () => reject(new Error("Could not load parcelLab script."));
            document.head.appendChild(scriptTag);
          }
        );
        return scopedWindow.__plDemoTrackLoaderPromise__.catch((error) => {
          scopedWindow.__plDemoTrackLoaderPromise__ = void 0;
          throw error;
        });
      };
      void ensureScript().then(() => {
        const liveContainer = document.getElementById(targetContainerId);
        if (!liveContainer) {
          return;
        }
        if (typeof scopedWindow.parcelLabTrackAndTrace?.initialize !== "function") {
          showContainerError(
            "parcelLab Track & Trace did not expose initialize()."
          );
          return;
        }
        scopedWindow.parcelLabTrackAndTrace.initialize({
          plUserId: Number(config.userId),
          lang: config.lang,
          show_searchForm: true,
          show_zipCodeInput: true,
          show_articleList: config.showArticleList,
          use_campaign_banners: true,
          containerId: targetContainerId
        });
        liveContainer.dataset.plDemoTrackRequested = "true";
        liveContainer.dataset.plDemoTrackRendered = "true";
      }).catch((error) => {
        showContainerError(
          error instanceof Error ? error.message : "parcelLab Track & Trace failed to render."
        );
      });
      return { ok: true };
    }
  });
  if (!result?.ok) {
    throw new Error(result?.error ?? "Track and trace render failed.");
  }
}
async function renderReturnsPortal(tabId, containerId, demoConfig) {
  const [{ result }] = await chrome.scripting.executeScript({
    target: { tabId },
    world: "MAIN",
    args: [containerId, demoConfig],
    func: (targetContainerId, config) => {
      const SCRIPT_ID = "pl-demo-returns-portal-loader";
      const SCRIPT_SRC = "https://returns-app.parcellab.com/static/plugin/js/loader.mjs";
      const scopedWindow = window;
      const container = document.getElementById(targetContainerId);
      if (!container) {
        return { ok: false, error: "Returns Portal container not found." };
      }
      const showContainerError = (message) => {
        container.dataset.plDemoReturnsRequested = "false";
        container.dataset.plDemoReturnsRendered = "false";
        const wrapper = document.createElement("div");
        wrapper.style.margin = "24px auto";
        wrapper.style.maxWidth = "560px";
        wrapper.style.padding = "16px 18px";
        wrapper.style.border = "1px solid rgba(239, 68, 68, 0.25)";
        wrapper.style.borderRadius = "12px";
        wrapper.style.background = "#fef2f2";
        wrapper.style.color = "#991b1b";
        wrapper.style.font = "500 14px/1.5 system-ui, sans-serif";
        wrapper.textContent = message;
        container.replaceChildren(wrapper);
      };
      const renderKey = `${config.accountName}:${config.portalCode}:${config.lang}`;
      if (container.dataset.plDemoReturnsKey === renderKey && container.dataset.plDemoReturnsRendered === "true") {
        return { ok: true };
      }
      container.dataset.plDemoReturnsKey = renderKey;
      container.dataset.plDemoReturnsRequested = "running";
      container.dataset.plDemoReturnsRendered = "false";
      const ensurePortalNode = () => {
        let portal = container.querySelector(
          "pl-returns-portal"
        );
        if (!portal) {
          container.replaceChildren();
          portal = document.createElement("pl-returns-portal");
          container.appendChild(portal);
        }
        portal.setAttribute("code", config.portalCode);
        portal.setAttribute("account-name", config.accountName);
        portal.setAttribute("lang", config.lang);
      };
      const ensureScript = async () => {
        if (customElements.get("pl-returns-portal")) {
          return;
        }
        if (scopedWindow.__plDemoReturnsLoaderPromise__) {
          return scopedWindow.__plDemoReturnsLoaderPromise__;
        }
        scopedWindow.__plDemoReturnsLoaderPromise__ = new Promise(
          (resolve, reject) => {
            const existingScript = document.getElementById(
              SCRIPT_ID
            );
            if (existingScript) {
              existingScript.addEventListener("load", () => resolve(), {
                once: true
              });
              existingScript.addEventListener(
                "error",
                () => reject(
                  new Error(
                    "Could not load the Returns Portal loader. Check script-src and frame-src CSP rules."
                  )
                ),
                { once: true }
              );
              return;
            }
            const scriptTag = document.createElement("script");
            scriptTag.id = SCRIPT_ID;
            scriptTag.type = "module";
            scriptTag.src = SCRIPT_SRC;
            scriptTag.onload = () => resolve();
            scriptTag.onerror = () => reject(
              new Error(
                "Could not load the Returns Portal loader. Check script-src and frame-src CSP rules."
              )
            );
            document.body.appendChild(scriptTag);
          }
        );
        return scopedWindow.__plDemoReturnsLoaderPromise__.catch((error) => {
          scopedWindow.__plDemoReturnsLoaderPromise__ = void 0;
          throw error;
        });
      };
      ensurePortalNode();
      void ensureScript().then(async () => {
        const liveContainer = document.getElementById(targetContainerId);
        if (!liveContainer) {
          return;
        }
        await customElements.whenDefined("pl-returns-portal");
        ensurePortalNode();
        liveContainer.dataset.plDemoReturnsRequested = "true";
        liveContainer.dataset.plDemoReturnsRendered = "true";
      }).catch((error) => {
        showContainerError(
          error instanceof Error ? error.message : "parcelLab Returns Portal failed to render."
        );
      });
      return { ok: true };
    }
  });
  if (!result?.ok) {
    throw new Error(result?.error ?? "Returns Portal render failed.");
  }
}
async function renderSelectionGuide(tabId, containerId, demoConfig) {
  const [{ result }] = await chrome.scripting.executeScript({
    target: { tabId },
    world: "MAIN",
    args: [containerId, demoConfig],
    func: (targetContainerId, config) => {
      const SCRIPT_ID = "pl-demo-selection-guide-script";
      const SCRIPT_SRC = "https://parcellab.github.io/selection-guide-ui/dist/size-recommender.iife.js";
      const scopedWindow = window;
      const container = document.getElementById(targetContainerId);
      if (!container) {
        return { ok: false, error: "Selection Guide container not found." };
      }
      const showContainerError = (message) => {
        container.dataset.plDemoSgRequested = "false";
        container.dataset.plDemoSgRendered = "false";
        const wrapper = document.createElement("div");
        wrapper.style.margin = "24px auto";
        wrapper.style.maxWidth = "560px";
        wrapper.style.padding = "16px 18px";
        wrapper.style.border = "1px solid rgba(239, 68, 68, 0.25)";
        wrapper.style.borderRadius = "12px";
        wrapper.style.background = "#fef2f2";
        wrapper.style.color = "#991b1b";
        wrapper.style.font = "500 14px/1.5 system-ui, sans-serif";
        wrapper.textContent = message;
        container.replaceChildren(wrapper);
      };
      const renderKey = `${config.accountId}:${config.productId}:${config.locale}:${config.appearance}:${config.density}:${config.surface}:${config.notFoundMode}`;
      if (container.dataset.plDemoSgKey === renderKey && container.dataset.plDemoSgRendered === "true") {
        return { ok: true };
      }
      container.dataset.plDemoSgKey = renderKey;
      container.dataset.plDemoSgRequested = "running";
      container.dataset.plDemoSgRendered = "false";
      const ensureScript = async () => {
        if (typeof scopedWindow.SizeRecommender?.init === "function") {
          return;
        }
        if (scopedWindow.__plDemoSelectionGuideLoaderPromise__) {
          return scopedWindow.__plDemoSelectionGuideLoaderPromise__;
        }
        scopedWindow.__plDemoSelectionGuideLoaderPromise__ = new Promise(
          (resolve, reject) => {
            const existingScript = document.getElementById(
              SCRIPT_ID
            );
            if (existingScript) {
              if (existingScript.dataset.plDemoLoaded === "true") {
                resolve();
                return;
              }
              existingScript.addEventListener("load", () => resolve(), {
                once: true
              });
              existingScript.addEventListener(
                "error",
                () => reject(new Error("Could not load Selection Guide script.")),
                { once: true }
              );
              return;
            }
            const scriptTag = document.createElement("script");
            scriptTag.id = SCRIPT_ID;
            scriptTag.async = true;
            scriptTag.src = SCRIPT_SRC;
            scriptTag.onload = () => {
              scriptTag.dataset.plDemoLoaded = "true";
              resolve();
            };
            scriptTag.onerror = () => reject(new Error("Could not load Selection Guide script."));
            document.head.appendChild(scriptTag);
          }
        );
        return scopedWindow.__plDemoSelectionGuideLoaderPromise__.catch((error) => {
          scopedWindow.__plDemoSelectionGuideLoaderPromise__ = void 0;
          throw error;
        });
      };
      void ensureScript().then(() => {
        const liveContainer = document.getElementById(targetContainerId);
        if (!liveContainer) {
          return;
        }
        if (typeof scopedWindow.SizeRecommender?.init !== "function") {
          showContainerError(
            "Selection Guide did not expose SizeRecommender.init()."
          );
          return;
        }
        liveContainer.replaceChildren();
        scopedWindow.SizeRecommender.init({
          target: liveContainer,
          accountId: config.accountId,
          productId: config.productId || void 0,
          locale: config.locale,
          appearance: config.appearance,
          density: config.density,
          surface: config.surface,
          notFoundMode: config.notFoundMode
        });
        liveContainer.dataset.plDemoSgRequested = "true";
        liveContainer.dataset.plDemoSgRendered = "true";
      }).catch((error) => {
        showContainerError(
          error instanceof Error ? error.message : "Selection Guide failed to render."
        );
      });
      return { ok: true };
    }
  });
  if (!result?.ok) {
    throw new Error(result?.error ?? "Selection Guide render failed.");
  }
}
var POLL_INTERVAL_MS = 1e3;
var POLL_MAX_ATTEMPTS = 60;
async function requireAccessToken() {
  const token = await getValidAccessToken();
  if (!token) {
    throw new Error("Not authenticated. Please log in first.");
  }
  return token;
}
async function handleChatbotExecute(request) {
  const { query, config, threadId } = request;
  if (!config.agentId) {
    return { ok: false, error: "Agent ID is required." };
  }
  try {
    const token = await requireAccessToken();
    let activeThreadId;
    if (threadId) {
      await sendFollowUpMessage(config, token, threadId, query);
      activeThreadId = threadId;
    } else {
      activeThreadId = await executeAgent(config, token, query);
    }
    const messages = await pollThread(config, token, activeThreadId);
    return { ok: true, threadId: activeThreadId, messages };
  } catch (error) {
    return {
      ok: false,
      error: error instanceof Error ? error.message : "Chatbot request failed."
    };
  }
}
async function executeAgent(config, token, query) {
  const url = `${config.baseUrl}/v4/agents/${encodeURIComponent(config.agentId)}/execute/`;
  const response = await fetch(url, {
    method: "POST",
    headers: {
      "Authorization": `Bearer ${token}`,
      "Content-Type": "application/json"
    },
    body: JSON.stringify({ query })
  });
  if (!response.ok) {
    const text = await response.text().catch(() => "");
    throw new Error(`Agent execute failed (${response.status}): ${text || response.statusText}`);
  }
  const data = await response.json();
  const threadId = data.threadId ?? data.thread_id;
  if (!threadId) {
    throw new Error("No threadId returned from execute endpoint.");
  }
  return threadId;
}
async function sendFollowUpMessage(config, token, threadId, query) {
  const url = `${config.baseUrl}/v4/agents/${encodeURIComponent(config.agentId)}/threads/${encodeURIComponent(threadId)}/messages/`;
  const response = await fetch(url, {
    method: "POST",
    headers: {
      "Authorization": `Bearer ${token}`,
      "Content-Type": "application/json"
    },
    body: JSON.stringify({ query })
  });
  if (!response.ok) {
    const text = await response.text().catch(() => "");
    throw new Error(`Follow-up message failed (${response.status}): ${text || response.statusText}`);
  }
}
async function pollThread(config, token, threadId) {
  for (let attempt = 0; attempt < POLL_MAX_ATTEMPTS; attempt++) {
    const url = `${config.baseUrl}/v4/agents/${encodeURIComponent(config.agentId)}/threads/${encodeURIComponent(threadId)}/`;
    const response = await fetch(url, {
      headers: {
        "Authorization": `Bearer ${token}`
      }
    });
    if (!response.ok) {
      const text = await response.text().catch(() => "");
      throw new Error(`Thread poll failed (${response.status}): ${text || response.statusText}`);
    }
    const data = await response.json();
    const status = data.executionStatus ?? data.execution_status ?? "";
    if (status === "completed" || status === "complete") {
      return extractMessages(data);
    }
    if (status === "failed" || status === "error") {
      const errorMsg = extractLastAssistantContent(data);
      throw new Error(errorMsg || "Agent execution failed.");
    }
    await sleep(POLL_INTERVAL_MS);
  }
  throw new Error("Agent execution timed out after 60 seconds.");
}
function extractMessages(data) {
  if (!Array.isArray(data.messages)) {
    return [];
  }
  return data.messages.filter(
    (msg) => typeof msg.role === "string" && typeof msg.content === "string"
  ).map((msg) => ({
    id: msg.id ?? crypto.randomUUID(),
    role: msg.role === "user" ? "user" : "assistant",
    content: msg.content,
    timestamp: msg.created_at ?? (/* @__PURE__ */ new Date()).toISOString()
  }));
}
function extractLastAssistantContent(data) {
  if (!Array.isArray(data.messages)) {
    return "";
  }
  const assistantMessages = data.messages.filter(
    (msg) => msg.role === "assistant" && typeof msg.content === "string"
  );
  return assistantMessages[assistantMessages.length - 1]?.content ?? "";
}
function sleep(ms) {
  return new Promise((resolve) => setTimeout(resolve, ms));
}
//# sourceMappingURL=background.js.map
