"use strict";
(() => {
  // src/shared/demo.ts
  function normalizeDemoConfig(value) {
    if (!value) {
      return void 0;
    }
    if ("kind" in value && value.kind === "returns-portal") {
      return {
        kind: "returns-portal",
        accountName: value.accountName,
        portalCode: value.portalCode,
        lang: value.lang
      };
    }
    if ("kind" in value && value.kind === "selection-guide") {
      const sg = value;
      return {
        kind: "selection-guide",
        accountId: sg.accountId,
        productId: sg.productId,
        locale: sg.locale,
        appearance: sg.appearance ?? "neutral",
        density: sg.density ?? "compact",
        surface: sg.surface ?? "subtle",
        notFoundMode: sg.notFoundMode ?? "true-to-size"
      };
    }
    if ("kind" in value && value.kind === "chatbot") {
      const cb = value;
      return {
        kind: "chatbot",
        agentId: cb.agentId,
        baseUrl: cb.baseUrl
      };
    }
    if ("kind" in value && value.kind === "track-and-trace") {
      return {
        kind: "track-and-trace",
        userId: value.userId,
        lang: value.lang,
        showArticleList: value.showArticleList
      };
    }
    if ("userId" in value) {
      return {
        kind: "track-and-trace",
        userId: value.userId,
        lang: value.lang,
        showArticleList: value.showArticleList
      };
    }
    return void 0;
  }

  // src/shared/url.ts
  function isWebUrl(value) {
    return Boolean(value && /^https?:\/\//.test(value));
  }
  function normalizeUrl(value) {
    const url = new URL(value);
    url.hash = "";
    return url.toString();
  }
  function normalizeScopeUrl(value) {
    const url = new URL(value);
    url.search = "";
    url.hash = "";
    return url.toString();
  }

  // src/shared/storage.ts
  var MODIFICATIONS_KEY = "savedModifications";
  async function getSavedModifications() {
    const result = await chrome.storage.local.get(
      MODIFICATIONS_KEY
    );
    return Array.isArray(result.savedModifications) ? result.savedModifications.map(normalizeSavedModification).sort(sortNewestFirst) : [];
  }
  async function saveModification(modification) {
    const existing = await getSavedModifications();
    const next = [modification, ...existing.filter((rule) => rule.id !== modification.id)];
    await chrome.storage.local.set({ [MODIFICATIONS_KEY]: next });
    return next;
  }
  function filterRulesForUrl(rules, normalizedScopeUrl) {
    return rules.filter(
      (rule) => resolveRuleScopeUrl(rule) === normalizedScopeUrl
    );
  }
  function resolveRuleScopeUrl(rule) {
    return rule.scopeUrl ?? normalizeScopeUrl(rule.url);
  }
  function sortNewestFirst(a, b) {
    return b.createdAt.localeCompare(a.createdAt);
  }
  function normalizeSavedModification(rule) {
    const demoConfig = normalizeDemoConfig(rule.demoConfig);
    if (!demoConfig || demoConfig === rule.demoConfig) {
      return rule;
    }
    return {
      ...rule,
      demoConfig
    };
  }

  // src/content/chatbot.ts
  var WIDGET_HOST_ID = "pl-demo-chatbot-host";
  var currentConfig = null;
  var threadId = null;
  var messages = [];
  var isLoading = false;
  var errorMessage = "";
  var isOpen = false;
  var shadowRoot = null;
  function injectChatbot(config) {
    currentConfig = config;
    if (document.getElementById(WIDGET_HOST_ID)) {
      return;
    }
    const host = document.createElement("div");
    host.id = WIDGET_HOST_ID;
    host.style.position = "fixed";
    host.style.bottom = "0";
    host.style.right = "0";
    host.style.zIndex = "2147483647";
    host.style.pointerEvents = "none";
    document.documentElement.appendChild(host);
    shadowRoot = host.attachShadow({ mode: "open" });
    render();
  }
  function removeChatbot() {
    const host = document.getElementById(WIDGET_HOST_ID);
    if (host) {
      host.remove();
    }
    currentConfig = null;
    threadId = null;
    messages = [];
    isLoading = false;
    errorMessage = "";
    isOpen = false;
    shadowRoot = null;
  }
  function render() {
    if (!shadowRoot) return;
    shadowRoot.innerHTML = "";
    const style = document.createElement("style");
    style.textContent = getStyles();
    shadowRoot.appendChild(style);
    const container = document.createElement("div");
    container.className = "chatbot-container";
    if (isOpen) {
      container.appendChild(buildChatWindow());
    }
    container.appendChild(buildLauncher());
    shadowRoot.appendChild(container);
  }
  function buildLauncher() {
    const btn = document.createElement("button");
    btn.className = "launcher";
    btn.title = "parcelLab Chatbot";
    btn.innerHTML = isOpen ? closeSvg() : chatSvg();
    btn.addEventListener("click", () => {
      isOpen = !isOpen;
      render();
      if (isOpen) {
        requestAnimationFrame(() => focusInput());
      }
    });
    return btn;
  }
  function buildChatWindow() {
    const win = document.createElement("div");
    win.className = "chat-window";
    const header = document.createElement("div");
    header.className = "chat-header";
    const title = document.createElement("span");
    title.className = "chat-title";
    title.textContent = "parcelLab Agent";
    header.appendChild(title);
    const closeBtn = document.createElement("button");
    closeBtn.className = "close-btn";
    closeBtn.title = "Close";
    closeBtn.innerHTML = closeSvg();
    closeBtn.addEventListener("click", () => {
      isOpen = false;
      render();
    });
    header.appendChild(closeBtn);
    win.appendChild(header);
    const messageList = document.createElement("div");
    messageList.className = "message-list";
    if (messages.length === 0 && !isLoading && !errorMessage) {
      const empty = document.createElement("div");
      empty.className = "empty-state";
      const greeting = document.createElement("p");
      greeting.className = "empty-greeting";
      greeting.textContent = "How can I help you today?";
      empty.appendChild(greeting);
      const suggestions = document.createElement("div");
      suggestions.className = "suggestions";
      const prompts = [
        "Where is my order?",
        "I want to return an item",
        "My package is damaged"
      ];
      for (const prompt of prompts) {
        const chip = document.createElement("button");
        chip.className = "suggestion-chip";
        chip.textContent = prompt;
        chip.addEventListener("click", () => {
          void sendMessage(prompt);
        });
        suggestions.appendChild(chip);
      }
      empty.appendChild(suggestions);
      messageList.appendChild(empty);
    }
    for (const msg of messages) {
      const bubble = document.createElement("div");
      bubble.className = `message ${msg.role}`;
      bubble.textContent = msg.content;
      messageList.appendChild(bubble);
    }
    if (isLoading) {
      const loader = document.createElement("div");
      loader.className = "message assistant loading";
      loader.innerHTML = '<span class="dot"></span><span class="dot"></span><span class="dot"></span>';
      messageList.appendChild(loader);
    }
    if (errorMessage) {
      const err = document.createElement("div");
      err.className = "error-banner";
      err.textContent = errorMessage;
      const dismiss = document.createElement("button");
      dismiss.className = "error-dismiss";
      dismiss.textContent = "Dismiss";
      dismiss.addEventListener("click", () => {
        errorMessage = "";
        render();
      });
      err.appendChild(dismiss);
      messageList.appendChild(err);
    }
    win.appendChild(messageList);
    requestAnimationFrame(() => {
      messageList.scrollTop = messageList.scrollHeight;
    });
    const inputArea = document.createElement("div");
    inputArea.className = "input-area";
    const input = document.createElement("input");
    input.className = "chat-input";
    input.type = "text";
    input.placeholder = "Type a message\u2026";
    input.disabled = isLoading;
    input.dataset.chatInput = "true";
    const submitBtn = document.createElement("button");
    submitBtn.className = "submit-btn";
    submitBtn.disabled = isLoading;
    submitBtn.innerHTML = sendSvg();
    const handleSubmit = () => {
      const query = input.value.trim();
      if (!query || isLoading) return;
      void sendMessage(query);
    };
    input.addEventListener("keydown", (e) => {
      if (e.key === "Enter" && !e.shiftKey) {
        e.preventDefault();
        handleSubmit();
      }
    });
    submitBtn.addEventListener("click", handleSubmit);
    inputArea.appendChild(input);
    inputArea.appendChild(submitBtn);
    win.appendChild(inputArea);
    return win;
  }
  function isExtensionContextValid() {
    try {
      return !!chrome.runtime?.id;
    } catch {
      return false;
    }
  }
  async function sendMessage(query) {
    if (!currentConfig) return;
    if (!isExtensionContextValid()) {
      errorMessage = "Extension was reloaded. Please refresh the page.";
      render();
      return;
    }
    messages.push({
      id: crypto.randomUUID(),
      role: "user",
      content: query,
      timestamp: (/* @__PURE__ */ new Date()).toISOString()
    });
    isLoading = true;
    errorMessage = "";
    render();
    try {
      const response = await chrome.runtime.sendMessage({
        type: "CHATBOT_EXECUTE",
        query,
        config: currentConfig,
        threadId: threadId ?? void 0
      });
      if (response?.ok) {
        threadId = response.threadId;
        messages = response.messages;
      } else {
        errorMessage = response?.error ?? "An unknown error occurred.";
      }
    } catch (error) {
      errorMessage = error instanceof Error ? error.message : "Failed to send message.";
    } finally {
      isLoading = false;
      render();
      requestAnimationFrame(() => focusInput());
    }
  }
  function focusInput() {
    if (!shadowRoot) return;
    const input = shadowRoot.querySelector("[data-chat-input]");
    input?.focus();
  }
  function chatSvg() {
    return `<svg width="24" height="24" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"><path d="M21 15a2 2 0 0 1-2 2H7l-4 4V5a2 2 0 0 1 2-2h14a2 2 0 0 1 2 2z"/></svg>`;
  }
  function closeSvg() {
    return `<svg width="18" height="18" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"><line x1="18" y1="6" x2="6" y2="18"/><line x1="6" y1="6" x2="18" y2="18"/></svg>`;
  }
  function sendSvg() {
    return `<svg width="18" height="18" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"><line x1="22" y1="2" x2="11" y2="13"/><polygon points="22 2 15 22 11 13 2 9 22 2"/></svg>`;
  }
  function getStyles() {
    return `
    :host {
      all: initial;
      font-family: system-ui, -apple-system, 'Segoe UI', Roboto, sans-serif;
      font-size: 14px;
      line-height: 1.5;
      color: #1e293b;
    }

    *, *::before, *::after {
      box-sizing: border-box;
      margin: 0;
      padding: 0;
    }

    .chatbot-container {
      position: fixed;
      bottom: 20px;
      right: 20px;
      display: flex;
      flex-direction: column;
      align-items: flex-end;
      gap: 12px;
      pointer-events: auto;
      z-index: 2147483647;
    }

    .launcher {
      width: 52px;
      height: 52px;
      border-radius: 50%;
      border: none;
      background: #3D3AD3;
      color: white;
      cursor: pointer;
      display: flex;
      align-items: center;
      justify-content: center;
      box-shadow: 0 4px 16px rgba(61, 58, 211, 0.35), 0 2px 4px rgba(0, 0, 0, 0.1);
      transition: background 0.15s ease, transform 0.15s ease, box-shadow 0.15s ease;
    }

    .launcher:hover {
      background: #3230b8;
      transform: scale(1.05);
      box-shadow: 0 6px 20px rgba(61, 58, 211, 0.45), 0 2px 4px rgba(0, 0, 0, 0.1);
    }

    .launcher:active {
      transform: scale(0.97);
    }

    .chat-window {
      width: 380px;
      max-height: 520px;
      background: white;
      border-radius: 16px;
      box-shadow: 0 16px 48px rgba(0, 0, 0, 0.16), 0 2px 8px rgba(0, 0, 0, 0.08);
      display: flex;
      flex-direction: column;
      overflow: hidden;
      border: 1px solid #e2e8f0;
    }

    .chat-header {
      display: flex;
      align-items: center;
      justify-content: space-between;
      padding: 14px 16px;
      background: #3D3AD3;
      color: white;
      flex-shrink: 0;
    }

    .chat-title {
      font-size: 15px;
      font-weight: 600;
      letter-spacing: -0.01em;
    }

    .close-btn {
      width: 28px;
      height: 28px;
      border-radius: 6px;
      border: none;
      background: rgba(255, 255, 255, 0.15);
      color: white;
      cursor: pointer;
      display: flex;
      align-items: center;
      justify-content: center;
      transition: background 0.15s ease;
    }

    .close-btn:hover {
      background: rgba(255, 255, 255, 0.25);
    }

    .message-list {
      flex: 1;
      overflow-y: auto;
      padding: 16px;
      display: flex;
      flex-direction: column;
      gap: 10px;
      min-height: 280px;
      max-height: 380px;
    }

    .empty-state {
      display: flex;
      flex-direction: column;
      align-items: center;
      justify-content: center;
      gap: 16px;
      height: 100%;
      min-height: 200px;
      color: #94a3b8;
      font-size: 13px;
    }

    .empty-greeting {
      font-size: 15px;
      font-weight: 500;
      color: #64748b;
    }

    .suggestions {
      display: flex;
      flex-direction: column;
      gap: 8px;
      width: 100%;
      max-width: 260px;
    }

    .suggestion-chip {
      display: block;
      width: 100%;
      padding: 10px 14px;
      border: 1px solid #e2e8f0;
      border-radius: 10px;
      background: white;
      color: #334155;
      font-size: 13px;
      font-family: inherit;
      line-height: 1.4;
      text-align: left;
      cursor: pointer;
      transition: border-color 0.15s ease, background 0.15s ease;
    }

    .suggestion-chip:hover {
      border-color: #3D3AD3;
      background: #f5f5ff;
      color: #3D3AD3;
    }

    .suggestion-chip:active {
      background: #eeeeff;
    }

    .message {
      max-width: 85%;
      padding: 10px 14px;
      border-radius: 14px;
      font-size: 13px;
      line-height: 1.5;
      word-wrap: break-word;
      white-space: pre-wrap;
    }

    .message.user {
      align-self: flex-end;
      background: #3D3AD3;
      color: white;
      border-bottom-right-radius: 4px;
    }

    .message.assistant {
      align-self: flex-start;
      background: #f1f5f9;
      color: #1e293b;
      border-bottom-left-radius: 4px;
    }

    .message.loading {
      display: flex;
      gap: 4px;
      padding: 12px 18px;
    }

    .dot {
      width: 7px;
      height: 7px;
      border-radius: 50%;
      background: #94a3b8;
      animation: bounce 1.2s infinite ease-in-out;
    }

    .dot:nth-child(2) { animation-delay: 0.15s; }
    .dot:nth-child(3) { animation-delay: 0.3s; }

    @keyframes bounce {
      0%, 60%, 100% { transform: translateY(0); }
      30% { transform: translateY(-6px); }
    }

    .error-banner {
      background: #fef2f2;
      border: 1px solid rgba(239, 68, 68, 0.25);
      border-radius: 10px;
      padding: 10px 14px;
      color: #991b1b;
      font-size: 12px;
      line-height: 1.4;
      display: flex;
      flex-direction: column;
      gap: 6px;
    }

    .error-dismiss {
      align-self: flex-end;
      border: none;
      background: none;
      color: #dc2626;
      font-size: 11px;
      font-weight: 600;
      cursor: pointer;
      padding: 2px 6px;
      border-radius: 4px;
      transition: background 0.15s;
    }

    .error-dismiss:hover {
      background: rgba(239, 68, 68, 0.1);
    }

    .input-area {
      display: flex;
      align-items: center;
      gap: 8px;
      padding: 12px 14px;
      border-top: 1px solid #e2e8f0;
      background: #fafbfc;
      flex-shrink: 0;
    }

    .chat-input {
      flex: 1;
      height: 38px;
      border: 1px solid #e2e8f0;
      border-radius: 10px;
      padding: 0 12px;
      font-size: 13px;
      font-family: inherit;
      color: #1e293b;
      background: white;
      outline: none;
      transition: border-color 0.15s ease, box-shadow 0.15s ease;
    }

    .chat-input:focus {
      border-color: #3D3AD3;
      box-shadow: 0 0 0 2px rgba(61, 58, 211, 0.15);
    }

    .chat-input:disabled {
      background: #f1f5f9;
      color: #94a3b8;
    }

    .chat-input::placeholder {
      color: #94a3b8;
    }

    .submit-btn {
      width: 38px;
      height: 38px;
      border-radius: 10px;
      border: none;
      background: #3D3AD3;
      color: white;
      cursor: pointer;
      display: flex;
      align-items: center;
      justify-content: center;
      flex-shrink: 0;
      transition: background 0.15s ease;
    }

    .submit-btn:hover {
      background: #3230b8;
    }

    .submit-btn:disabled {
      background: #cbd5e1;
      cursor: default;
    }
  `;
  }

  // src/content/index.ts
  var OVERLAY_ID = "pl-demo-picker-overlay";
  var TOAST_ID = "pl-demo-picker-toast";
  var TOOLTIP_ID = "pl-demo-picker-tooltip";
  var INTERNAL_PREFIX = "pl-demo-picker-";
  var appliedStates = /* @__PURE__ */ new Map();
  function isExtensionContextValid2() {
    try {
      return !!chrome.runtime?.id;
    } catch {
      return false;
    }
  }
  if (!window.__PL_DEMO_CONTROLLER__) {
    window.__PL_DEMO_CONTROLLER__ = createController();
    void window.__PL_DEMO_CONTROLLER__.init();
  }
  function createController() {
    let pickerState = null;
    let observer = null;
    let applyTimer = 0;
    let lastKnownScopeUrl = normalizeCurrentScopeUrl();
    let hasInstalledNavigationHooks = false;
    async function init() {
      chrome.runtime.onMessage.addListener(
        (message, _sender, sendResponse) => {
          void handleMessage(message).then((response) => sendResponse(response)).catch(
            (error) => sendResponse({
              ok: false,
              error: error instanceof Error ? error.message : String(error)
            })
          );
          return true;
        }
      );
      installNavigationHooks();
      installObserver();
      await applyRulesForCurrentUrl();
    }
    async function handleMessage(message) {
      switch (message.type) {
        case "PING":
          return { ok: true };
        case "START_PICKER":
          startPicker(message.action, message.html, message.demoConfig);
          return { ok: true };
        case "RESTORE_RULES":
          restoreRules(message.ruleIds);
          await applyRulesForCurrentUrl();
          return { ok: true };
        case "INJECT_CHATBOT":
          injectChatbot(message.config);
          return { ok: true };
        case "REMOVE_CHATBOT":
          removeChatbot();
          return { ok: true };
        default:
          return { ok: false, error: "Unsupported request" };
      }
    }
    function installObserver() {
      if (observer) {
        return;
      }
      observer = new MutationObserver(() => {
        if (!isExtensionContextValid2()) {
          observer?.disconnect();
          return;
        }
        if (applyTimer) {
          window.clearTimeout(applyTimer);
        }
        applyTimer = window.setTimeout(() => {
          if (isExtensionContextValid2()) {
            void applyRulesForCurrentUrl();
          }
        }, 120);
      });
      const root = document.documentElement ?? document.body;
      if (!root) {
        return;
      }
      observer.observe(root, {
        childList: true,
        subtree: true
      });
    }
    function installNavigationHooks() {
      if (hasInstalledNavigationHooks) {
        return;
      }
      hasInstalledNavigationHooks = true;
      const onLocationChange = () => {
        if (!isExtensionContextValid2()) return;
        const currentScopeUrl = normalizeCurrentScopeUrl();
        if (currentScopeUrl === lastKnownScopeUrl) {
          return;
        }
        lastKnownScopeUrl = currentScopeUrl;
        restoreRules(Array.from(appliedStates.keys()));
        void applyRulesForCurrentUrl();
      };
      const originalPushState = history.pushState;
      history.pushState = function pushState(...args) {
        const result = originalPushState.apply(this, args);
        window.dispatchEvent(new Event("pl-demo-url-change"));
        return result;
      };
      const originalReplaceState = history.replaceState;
      history.replaceState = function replaceState(...args) {
        const result = originalReplaceState.apply(this, args);
        window.dispatchEvent(new Event("pl-demo-url-change"));
        return result;
      };
      window.addEventListener("popstate", onLocationChange);
      window.addEventListener("hashchange", onLocationChange);
      window.addEventListener("pl-demo-url-change", onLocationChange);
    }
    async function applyRulesForCurrentUrl() {
      if (!isExtensionContextValid2()) return;
      const normalizedScopeUrl = normalizeCurrentScopeUrl();
      if (!normalizedScopeUrl) {
        return;
      }
      const rules = filterRulesForUrl(
        await getSavedModifications(),
        normalizedScopeUrl
      );
      const activeRuleIds = new Set(rules.map((rule) => rule.id));
      for (const ruleId of Array.from(appliedStates.keys())) {
        if (!activeRuleIds.has(ruleId)) {
          restoreRule(ruleId);
        }
      }
      for (const rule of rules) {
        applyRule(rule);
      }
    }
    function applyRule(rule) {
      const element = document.querySelector(rule.selector);
      if (!(element instanceof HTMLElement)) {
        return;
      }
      const currentState = appliedStates.get(rule.id);
      if (currentState && currentState.element !== element) {
        restoreRule(rule.id);
      }
      if (rule.action === "hide") {
        const state2 = appliedStates.get(rule.id);
        if (!state2) {
          appliedStates.set(rule.id, {
            action: "hide",
            element,
            displayValue: element.style.getPropertyValue("display"),
            displayPriority: element.style.getPropertyPriority("display")
          });
        }
        element.style.setProperty("display", "none", "important");
        return;
      }
      const demoConfig = normalizeDemoConfig(rule.demoConfig);
      if (demoConfig?.kind === "chatbot") {
        injectChatbot({ agentId: demoConfig.agentId, baseUrl: demoConfig.baseUrl });
        return;
      }
      if (demoConfig?.kind === "selection-guide") {
        renderSelectionGuideRule(element, rule);
        return;
      }
      const state = appliedStates.get(rule.id);
      if (!state) {
        appliedStates.set(rule.id, {
          action: "replace",
          element,
          originalHtml: element.innerHTML
        });
      }
      if (demoConfig?.kind === "track-and-trace") {
        renderTrackAndTraceRule(element, rule);
        return;
      }
      if (demoConfig?.kind === "returns-portal") {
        renderReturnsPortalRule(element, rule);
        return;
      }
      element.innerHTML = rule.html;
    }
    function restoreRules(ruleIds) {
      ruleIds.forEach((ruleId) => restoreRule(ruleId));
    }
    function restoreRule(ruleId) {
      const state = appliedStates.get(ruleId);
      if (!state) {
        return;
      }
      if (!state.element.isConnected) {
        appliedStates.delete(ruleId);
        return;
      }
      if (state.action === "hide") {
        if (state.displayValue) {
          state.element.style.setProperty(
            "display",
            state.displayValue,
            state.displayPriority
          );
        } else {
          state.element.style.removeProperty("display");
        }
      } else if (state.action === "insert-after") {
        if (state.insertedNode.isConnected) {
          state.insertedNode.remove();
        }
      } else {
        state.element.innerHTML = state.originalHtml;
      }
      appliedStates.delete(ruleId);
    }
    function startPicker(action, html, demoConfig) {
      stopPicker();
      pickerState = {
        action,
        html,
        demoConfig,
        hoveredElement: null
      };
      document.addEventListener("mousemove", handlePointerMove, true);
      document.addEventListener("click", handleClick, true);
      document.addEventListener("keydown", handleKeydown, true);
      window.addEventListener("scroll", syncOverlayToHoveredElement, true);
      window.addEventListener("resize", syncOverlayToHoveredElement, true);
      showToast(
        action === "hide" ? "Selection mode: click any element to hide it. Press Escape to cancel." : "Selection mode: click any element to replace its contents. Press Escape to cancel."
      );
    }
    function stopPicker() {
      pickerState = null;
      document.removeEventListener("mousemove", handlePointerMove, true);
      document.removeEventListener("click", handleClick, true);
      document.removeEventListener("keydown", handleKeydown, true);
      window.removeEventListener("scroll", syncOverlayToHoveredElement, true);
      window.removeEventListener("resize", syncOverlayToHoveredElement, true);
      removeOverlayUi();
    }
    function handlePointerMove(event) {
      if (!pickerState) {
        return;
      }
      const nextElement = getSelectableElement(event.target);
      if (pickerState.hoveredElement === nextElement) {
        syncOverlayToHoveredElement();
        return;
      }
      pickerState.hoveredElement = nextElement;
      syncOverlayToHoveredElement();
    }
    async function handleClick(event) {
      if (!pickerState || !isExtensionContextValid2()) {
        return;
      }
      const element = getSelectableElement(event.target);
      if (!element) {
        return;
      }
      event.preventDefault();
      event.stopPropagation();
      event.stopImmediatePropagation();
      const normalizedUrl = normalizeCurrentUrl();
      if (!normalizedUrl) {
        showToast("This page cannot be saved as a demo rule.");
        stopPicker();
        return;
      }
      const selector = createUniqueSelector(element);
      const summary = summarizeElement(element);
      const rule = {
        id: crypto.randomUUID(),
        url: normalizedUrl,
        scopeUrl: normalizeCurrentScopeUrl(),
        pageTitle: document.title.trim() || window.location.hostname,
        selector,
        action: pickerState.action,
        html: pickerState.action === "replace" ? pickerState.html : "",
        demoConfig: pickerState.action === "replace" ? pickerState.demoConfig : void 0,
        summary,
        createdAt: (/* @__PURE__ */ new Date()).toISOString()
      };
      await saveModification(rule);
      applyRule(rule);
      stopPicker();
      showToast(
        rule.action === "hide" ? `Saved hide rule for ${summary}.` : `Saved replacement rule for ${summary}.`
      );
      try {
        await chrome.runtime.sendMessage({ type: "SYNC_RULES" });
      } catch {
      }
    }
    function handleKeydown(event) {
      if (event.key !== "Escape") {
        return;
      }
      event.preventDefault();
      stopPicker();
      showToast("Selection cancelled.");
    }
    function syncOverlayToHoveredElement() {
      if (!pickerState?.hoveredElement) {
        removeOverlayUi();
        return;
      }
      const rect = pickerState.hoveredElement.getBoundingClientRect();
      const overlay = ensureOverlayNode();
      const tooltip = ensureTooltipNode();
      overlay.style.top = `${rect.top - 2}px`;
      overlay.style.left = `${rect.left - 2}px`;
      overlay.style.width = `${rect.width}px`;
      overlay.style.height = `${rect.height}px`;
      tooltip.textContent = `${pickerState.action === "hide" ? "Hide" : "Replace"} ${summarizeElement(
        pickerState.hoveredElement
      )}`;
      tooltip.style.top = `${Math.max(12, rect.top - 34)}px`;
      tooltip.style.left = `${Math.max(12, rect.left)}px`;
    }
    return { init };
  }
  function normalizeCurrentUrl() {
    return isWebUrl(window.location.href) ? normalizeUrl(window.location.href) : "";
  }
  function normalizeCurrentScopeUrl() {
    return isWebUrl(window.location.href) ? normalizeScopeUrl(window.location.href) : "";
  }
  function getSelectableElement(target) {
    const element = target instanceof HTMLElement ? target : target instanceof Text ? target.parentElement : null;
    if (!element) {
      return null;
    }
    if (element.id.startsWith(INTERNAL_PREFIX)) {
      return null;
    }
    if (element.closest(`[id^="${INTERNAL_PREFIX}"]`)) {
      return null;
    }
    return element;
  }
  function summarizeElement(element) {
    const parts = [element.tagName.toLowerCase()];
    if (element.id) {
      parts.push(`#${element.id}`);
    }
    const classNames = Array.from(element.classList).slice(0, 2);
    if (classNames.length > 0) {
      parts.push(`.${classNames.join(".")}`);
    }
    return parts.join("");
  }
  function ensureOverlayNode() {
    let overlay = document.getElementById(OVERLAY_ID);
    if (overlay) {
      return overlay;
    }
    overlay = document.createElement("div");
    overlay.id = OVERLAY_ID;
    overlay.style.position = "fixed";
    overlay.style.zIndex = "2147483647";
    overlay.style.pointerEvents = "none";
    overlay.style.border = "2px solid #ff6a2b";
    overlay.style.boxShadow = "0 0 0 9999px rgba(17, 12, 8, 0.08)";
    overlay.style.borderRadius = "6px";
    overlay.style.background = "rgba(255, 106, 43, 0.08)";
    document.documentElement.appendChild(overlay);
    return overlay;
  }
  function ensureTooltipNode() {
    let tooltip = document.getElementById(TOOLTIP_ID);
    if (tooltip) {
      return tooltip;
    }
    tooltip = document.createElement("div");
    tooltip.id = TOOLTIP_ID;
    tooltip.style.position = "fixed";
    tooltip.style.zIndex = "2147483647";
    tooltip.style.pointerEvents = "none";
    tooltip.style.padding = "6px 10px";
    tooltip.style.background = "#1f1713";
    tooltip.style.color = "#fff8f0";
    tooltip.style.font = "600 12px/1.4 system-ui, sans-serif";
    tooltip.style.borderRadius = "999px";
    tooltip.style.boxShadow = "0 12px 28px rgba(0, 0, 0, 0.24)";
    document.documentElement.appendChild(tooltip);
    return tooltip;
  }
  function showToast(message) {
    let toast = document.getElementById(TOAST_ID);
    if (!toast) {
      toast = document.createElement("div");
      toast.id = TOAST_ID;
      toast.style.position = "fixed";
      toast.style.right = "20px";
      toast.style.bottom = "20px";
      toast.style.zIndex = "2147483647";
      toast.style.maxWidth = "420px";
      toast.style.padding = "12px 14px";
      toast.style.borderRadius = "14px";
      toast.style.background = "linear-gradient(135deg, rgba(255,106,43,0.96), rgba(255,140,79,0.96))";
      toast.style.color = "#1b130d";
      toast.style.font = "600 13px/1.5 system-ui, sans-serif";
      toast.style.boxShadow = "0 16px 40px rgba(52, 22, 4, 0.24)";
      document.documentElement.appendChild(toast);
    }
    toast.textContent = message;
    window.clearTimeout(Number(toast.dataset.timeoutId ?? "0"));
    const timeoutId = window.setTimeout(() => {
      if (toast?.isConnected) {
        toast.remove();
      }
    }, 2600);
    toast.dataset.timeoutId = String(timeoutId);
  }
  function removeOverlayUi() {
    document.getElementById(OVERLAY_ID)?.remove();
    document.getElementById(TOOLTIP_ID)?.remove();
  }
  function createUniqueSelector(element) {
    if (element.id) {
      const selector = `#${CSS.escape(element.id)}`;
      if (isUniqueSelector(selector)) {
        return selector;
      }
    }
    const segments = [];
    let current = element;
    while (current && current !== document.body) {
      const base = buildSelectorSegment(current);
      segments.unshift(base);
      const selector = segments.join(" > ");
      if (isUniqueSelector(selector)) {
        return selector;
      }
      current = current.parentElement;
    }
    return ["body", ...segments].join(" > ");
  }
  function buildSelectorSegment(element) {
    const stableAttribute = [
      "data-testid",
      "data-test",
      "data-qa",
      "data-cy"
    ].map((attributeName) => ({
      attributeName,
      value: element.getAttribute(attributeName)
    })).find((entry) => entry.value);
    if (stableAttribute?.value) {
      return `${element.tagName.toLowerCase()}[${stableAttribute.attributeName}="${escapeAttributeValue(
        stableAttribute.value
      )}"]`;
    }
    let segment = element.tagName.toLowerCase();
    if (element.id) {
      return `${segment}#${CSS.escape(element.id)}`;
    }
    const stableClasses = Array.from(element.classList).filter((className) => /^[A-Za-z][A-Za-z0-9_-]{0,40}$/.test(className)).slice(0, 2);
    if (stableClasses.length > 0) {
      segment += stableClasses.map((className) => `.${CSS.escape(className)}`).join("");
    }
    if (!element.parentElement) {
      return segment;
    }
    const siblings = Array.from(element.parentElement.children).filter(
      (sibling) => sibling.tagName === element.tagName
    );
    if (siblings.length > 1) {
      const position = siblings.indexOf(element) + 1;
      segment += `:nth-of-type(${position})`;
    }
    return segment;
  }
  function isUniqueSelector(selector) {
    try {
      return document.querySelectorAll(selector).length === 1;
    } catch {
      return false;
    }
  }
  function escapeAttributeValue(value) {
    return value.replace(/\\/g, "\\\\").replace(/"/g, '\\"');
  }
  function renderSelectionGuideRule(element, rule) {
    const demoConfig = normalizeDemoConfig(rule.demoConfig);
    if (demoConfig?.kind !== "selection-guide") {
      return;
    }
    const containerId = `parcellab-selection-guide-${rule.id}`;
    const renderKey = `${demoConfig.accountId}:${demoConfig.productId}:${demoConfig.locale}:${demoConfig.appearance}:${demoConfig.density}:${demoConfig.surface}:${demoConfig.notFoundMode}`;
    let container = document.getElementById(containerId);
    if (!container) {
      container = document.createElement("div");
      container.id = containerId;
      container.dataset.plDemoSgRoot = "true";
      container.dataset.plDemoSgKey = renderKey;
      container.style.position = "relative";
      container.style.marginTop = "8px";
      const loadingCopy = document.createElement("div");
      loadingCopy.dataset.plDemoSgPlaceholder = "true";
      loadingCopy.style.padding = "12px 16px";
      loadingCopy.style.border = "1px solid rgba(148, 163, 184, 0.35)";
      loadingCopy.style.borderRadius = "12px";
      loadingCopy.style.background = "#f8fafc";
      loadingCopy.style.color = "#334155";
      loadingCopy.style.font = "500 14px/1.5 system-ui, sans-serif";
      loadingCopy.textContent = "Loading Selection Guide\u2026";
      container.appendChild(loadingCopy);
      element.insertAdjacentElement("afterend", container);
      appliedStates.set(rule.id, {
        action: "insert-after",
        element,
        insertedNode: container
      });
    }
    if (container.dataset.plDemoSgKey === renderKey && (container.dataset.plDemoSgRequested === "pending" || container.dataset.plDemoSgRequested === "running" || container.dataset.plDemoSgRendered === "true")) {
      return;
    }
    container.dataset.plDemoSgKey = renderKey;
    container.dataset.plDemoSgRequested = "pending";
    container.dataset.plDemoSgRendered = "false";
    void chrome.runtime.sendMessage({
      type: "RENDER_SELECTION_GUIDE",
      containerId,
      demoConfig
    }).then((response) => {
      const liveContainer = document.getElementById(containerId);
      if (!liveContainer) {
        return;
      }
      if (!response?.ok) {
        liveContainer.dataset.plDemoSgRequested = "false";
        liveContainer.dataset.plDemoSgRendered = "false";
        showPluginError(
          liveContainer,
          response?.error ?? "Selection Guide failed to render.",
          "pl-demo-sg-error"
        );
      }
    }).catch((error) => {
      const liveContainer = document.getElementById(containerId);
      if (liveContainer) {
        liveContainer.dataset.plDemoSgRequested = "false";
        liveContainer.dataset.plDemoSgRendered = "false";
        showPluginError(
          liveContainer,
          error instanceof Error ? error.message : "Selection Guide failed to render.",
          "pl-demo-sg-error"
        );
      }
    });
  }
  function renderTrackAndTraceRule(element, rule) {
    const demoConfig = normalizeDemoConfig(rule.demoConfig);
    if (demoConfig?.kind !== "track-and-trace") {
      return;
    }
    const containerId = `parcellab-track-and-trace-${rule.id}`;
    const renderKey = `${demoConfig.userId}:${demoConfig.lang}:${String(
      demoConfig.showArticleList
    )}`;
    let container = element.querySelector(
      `#${CSS.escape(containerId)}`
    );
    if (!container) {
      element.innerHTML = "";
      container = document.createElement("div");
      container.id = containerId;
      container.dataset.plDemoTrackRoot = "true";
      container.dataset.plDemoTrackKey = renderKey;
      container.style.position = "relative";
      container.style.minHeight = "320px";
      const spinner = document.createElement("img");
      spinner.src = "https://cdn.parcellab.com/img/loading-spinner-1.gif";
      spinner.alt = "loading";
      spinner.style.display = "block";
      spinner.style.margin = "32px auto";
      container.appendChild(spinner);
      element.appendChild(container);
    }
    if (container.dataset.plDemoTrackKey === renderKey && (container.dataset.plDemoTrackRequested === "pending" || container.dataset.plDemoTrackRequested === "running" || container.dataset.plDemoTrackRendered === "true")) {
      return;
    }
    container.dataset.plDemoTrackKey = renderKey;
    container.dataset.plDemoTrackRequested = "pending";
    container.dataset.plDemoTrackRendered = "false";
    void chrome.runtime.sendMessage({
      type: "RENDER_TRACK_AND_TRACE",
      containerId,
      demoConfig
    }).then((response) => {
      if (!container) {
        return;
      }
      if (!response?.ok) {
        container.dataset.plDemoTrackRequested = "false";
        container.dataset.plDemoTrackRendered = "false";
        showTrackAndTraceError(
          container,
          response?.error ?? "parcelLab Track & Trace failed to render."
        );
      }
    }).catch((error) => {
      if (container) {
        container.dataset.plDemoTrackRequested = "false";
        container.dataset.plDemoTrackRendered = "false";
        showTrackAndTraceError(
          container,
          error instanceof Error ? error.message : "parcelLab Track & Trace failed to render."
        );
      }
    });
  }
  function renderReturnsPortalRule(element, rule) {
    const demoConfig = normalizeDemoConfig(rule.demoConfig);
    if (demoConfig?.kind !== "returns-portal") {
      return;
    }
    const containerId = `parcellab-returns-portal-${rule.id}`;
    const renderKey = `${demoConfig.accountName}:${demoConfig.portalCode}:${demoConfig.lang}`;
    let container = element.querySelector(
      `#${CSS.escape(containerId)}`
    );
    if (!container) {
      element.innerHTML = "";
      container = document.createElement("div");
      container.id = containerId;
      container.dataset.plDemoReturnsRoot = "true";
      container.dataset.plDemoReturnsKey = renderKey;
      container.style.position = "relative";
      container.style.minHeight = "320px";
      const loadingCopy = document.createElement("div");
      loadingCopy.dataset.plDemoReturnsPlaceholder = "true";
      loadingCopy.style.margin = "32px auto";
      loadingCopy.style.maxWidth = "560px";
      loadingCopy.style.padding = "16px 18px";
      loadingCopy.style.border = "1px solid rgba(148, 163, 184, 0.35)";
      loadingCopy.style.borderRadius = "12px";
      loadingCopy.style.background = "#f8fafc";
      loadingCopy.style.color = "#334155";
      loadingCopy.style.font = "500 14px/1.5 system-ui, sans-serif";
      loadingCopy.textContent = "Loading parcelLab Returns Portal\u2026";
      container.appendChild(loadingCopy);
      element.appendChild(container);
    }
    if (container.dataset.plDemoReturnsKey === renderKey && (container.dataset.plDemoReturnsRequested === "pending" || container.dataset.plDemoReturnsRequested === "running" || container.dataset.plDemoReturnsRendered === "true")) {
      return;
    }
    container.dataset.plDemoReturnsKey = renderKey;
    container.dataset.plDemoReturnsRequested = "pending";
    container.dataset.plDemoReturnsRendered = "false";
    void chrome.runtime.sendMessage({
      type: "RENDER_RETURNS_PORTAL",
      containerId,
      demoConfig
    }).then((response) => {
      if (!container) {
        return;
      }
      if (!response?.ok) {
        container.dataset.plDemoReturnsRequested = "false";
        container.dataset.plDemoReturnsRendered = "false";
        showReturnsPortalError(
          container,
          response?.error ?? "parcelLab Returns Portal failed to render."
        );
      }
    }).catch((error) => {
      if (container) {
        container.dataset.plDemoReturnsRequested = "false";
        container.dataset.plDemoReturnsRendered = "false";
        showReturnsPortalError(
          container,
          error instanceof Error ? error.message : "parcelLab Returns Portal failed to render."
        );
      }
    });
  }
  function showTrackAndTraceError(container, message) {
    showPluginError(container, message, "pl-demo-track-error");
  }
  function showReturnsPortalError(container, message) {
    showPluginError(container, message, "pl-demo-returns-error");
  }
  function showPluginError(container, message, errorKey) {
    const existingMessage = container.querySelector(
      `[data-${errorKey}="true"]`
    );
    if (existingMessage) {
      existingMessage.textContent = message;
      return;
    }
    const wrapper = document.createElement("div");
    wrapper.setAttribute(`data-${errorKey}`, "true");
    wrapper.style.margin = "24px auto";
    wrapper.style.maxWidth = "560px";
    wrapper.style.padding = "16px 18px";
    wrapper.style.border = "1px solid rgba(239, 68, 68, 0.25)";
    wrapper.style.borderRadius = "12px";
    wrapper.style.background = "#fef2f2";
    wrapper.style.color = "#991b1b";
    wrapper.style.font = "500 14px/1.5 system-ui, sans-serif";
    wrapper.textContent = message;
    container.replaceChildren(wrapper);
  }
})();
//# sourceMappingURL=content.js.map
